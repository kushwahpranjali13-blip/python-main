from django.urls import path
from . import views

urlpatterns = [
    path('', views.home),
    
    path('login/', views.login_view),
    path('logout/', views.logout_view),
    
    
    path('vendor/', views.vendor_list),
    path('vendor/delete/<int:id>/', views.delete_vendor),
    path('vendor/update/<int:id>/', views.update_vendor),
    path('vendor/detail/<int:id>/', views.vendor_detail),

    path('product/', views.product_list),
    path('product/delete/<int:id>/', views.delete_product),
    path('product/update/<int:id>/', views.update_product),
    path('product/detail/<int:id>/', views.product_detail),

    path('inventory/', views.inventory_list),
    path('inventory/delete/<int:id>/', views.delete_inventory),
    path('inventory/update/<int:id>/', views.update_inventory),  
    path('inventory/detail/<int:id>/', views.inventory_detail),

    path('order/', views.order_list),
    path('order/delete/<int:id>/', views.delete_order),
    path('order/update/<int:id>/', views.update_order),  
    path('order/detail/<int:id>/', views.order_detail),

    path('purchase/', views.purchase_list),

    path('api/secure/', views.secure_api),
]