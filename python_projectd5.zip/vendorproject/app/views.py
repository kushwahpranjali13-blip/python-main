from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.http import HttpResponse  
from .models import Vendor, Product, Inventory, Order, Purchase
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response


# ===== ROLE CHECK =====
def is_admin(user):
    return user.groups.filter(name='Admin').exists()

def is_manager(user):
    return user.groups.filter(name='Manager').exists()


# ===== HOME =====
def home(request):
    return redirect('/login/')


# ===== VENDOR =====
@login_required
def vendor_list(request):
    if not (is_admin(request.user) or is_manager(request.user)):
        return render(request, "denied.html")

    if request.method == "POST":
        name = request.POST.get("name")
        if name:
            Vendor.objects.create(name=name)
            return redirect('/product/')

    vendors = Vendor.objects.all()
    return render(request, "vendor.html", {"vendors": vendors})


def vendor_detail(request, id):
    vendor = Vendor.objects.get(id=id)
    return render(request, "vendor_detail.html", {"vendor": vendor})


def update_vendor(request, id):
    if not is_admin(request.user):
        return HttpResponse("Access Denied")

    vendor = Vendor.objects.get(id=id)

    if request.method == "POST":
        vendor.name = request.POST.get("name")
        vendor.save()
        return redirect('/vendor/')

    return render(request, "update_vendor.html", {"vendor": vendor})


def delete_vendor(request, id):
    if not is_admin(request.user):
        return HttpResponse("Access Denied")

    Vendor.objects.get(id=id).delete()
    return redirect('/vendor/')


# ===== PRODUCT =====
@login_required
def product_list(request):
    if not (is_admin(request.user) or is_manager(request.user)):
        return render(request, "denied.html")

    if request.method == "POST":
        name = request.POST.get("name")
        price = request.POST.get("price")
        vendor_id = request.POST.get("vendor")

        if name and price and vendor_id:
            vendor = Vendor.objects.get(id=vendor_id)
            Product.objects.create(name=name, price=price, vendor=vendor)
            return redirect('/inventory/')

    products = Product.objects.all()
    vendors = Vendor.objects.all()
    return render(request, "product.html", {"products": products, "vendors": vendors})


def product_detail(request, id):
    product = Product.objects.get(id=id)
    return render(request, "product_detail.html", {"product": product})


def update_product(request, id):
    if not is_admin(request.user):
        return HttpResponse("Access Denied")

    product = Product.objects.get(id=id)

    if request.method == "POST":
        product.name = request.POST.get("name")
        product.price = request.POST.get("price")
        product.vendor = Vendor.objects.get(id=request.POST.get("vendor"))
        product.save()
        return redirect('/product/')

    vendors = Vendor.objects.all()
    return render(request, "update_product.html", {
        "product": product,
        "vendors": vendors
    })


def delete_product(request, id):
    if not is_admin(request.user):
        return HttpResponse("Access Denied")

    Product.objects.get(id=id).delete()
    return redirect('/product/')


# ===== INVENTORY =====
@login_required
def inventory_list(request):
    if not (is_admin(request.user) or is_manager(request.user)):
        return render(request, "denied.html")

    if request.method == "POST":
        product_id = request.POST.get("product")
        quantity = request.POST.get("quantity")

        if product_id and quantity:
            product = Product.objects.get(id=product_id)
            quantity = int(quantity)

            inventory = Inventory.objects.filter(product=product).first()

            if inventory:
                inventory.quantity += quantity
                inventory.save()
            else:
                Inventory.objects.create(product=product, quantity=quantity)

            return redirect('/order/')

    inventories = Inventory.objects.all()
    products = Product.objects.all()
    return render(request, "inventory.html", {"inventories": inventories, "products": products})


def inventory_detail(request, id):
    inventory = Inventory.objects.get(id=id)
    return render(request, "inventory_detail.html", {"inventory": inventory})


def update_inventory(request, id):
    if not is_admin(request.user):
        return HttpResponse("Access Denied")

    inventory = Inventory.objects.get(id=id)

    if request.method == "POST":
        inventory.quantity = request.POST.get("quantity")
        inventory.save()
        return redirect('/inventory/')

    return render(request, "update_inventory.html", {"inventory": inventory})


def delete_inventory(request, id):
    if not is_admin(request.user):
        return HttpResponse("Access Denied")

    Inventory.objects.get(id=id).delete()
    return redirect('/inventory/')


# ===== ORDER =====
@login_required
def order_list(request):
    message = ""

    if request.method == "POST":
        product_id = request.POST.get("product")
        quantity = request.POST.get("quantity")

        if product_id and quantity:
            product = Product.objects.get(id=product_id)
            quantity = int(quantity)

            inventory = Inventory.objects.filter(product=product).first()

            if inventory and inventory.quantity >= quantity:
                inventory.quantity -= quantity
                inventory.save()

                Order.objects.create(product=product, quantity=quantity)
                message = "Order placed successfully"
            else:
                message = "Not enough stock"

    orders = Order.objects.all()
    products = Product.objects.all()

    return render(request, "order.html", {
        "orders": orders,
        "products": products,
        "message": message
    })


def update_order(request, id):
    order = Order.objects.get(id=id)

    if request.method == "POST":
        order.quantity = request.POST.get("quantity")
        order.save()
        return redirect('/order/')

    return render(request, "update_order.html", {"order": order})


def delete_order(request, id):
    Order.objects.get(id=id).delete()
    return redirect('/order/')


def order_detail(request, id):
    order = Order.objects.get(id=id)
    return render(request, "order_detail.html", {"order": order})


# ===== PURCHASE =====
@login_required
def purchase_list(request):
    if not (is_admin(request.user) or is_manager(request.user)):
        return render(request, "denied.html")

    if request.method == "POST":
        product_id = request.POST.get("product")
        quantity = int(request.POST.get("quantity"))

        product = Product.objects.get(id=product_id)

        inventory = Inventory.objects.get(product=product)
        inventory.quantity += quantity
        inventory.save()

        Purchase.objects.create(product=product, quantity=quantity)

    purchases = Purchase.objects.all()
    products = Product.objects.all()

    return render(request, "purchase.html", {
        "purchases": purchases,
        "products": products
    })


# ===== AUTH =====
def login_view(request):
    message = ""

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user:
            login(request, user)

            if is_admin(user):
                return redirect('/vendor/')
            elif is_manager(user):
                return redirect('/product/')
            else:
                return redirect('/order/')
        else:
            message = "Invalid username or password"

    return render(request, "login.html", {"message": message})


def logout_view(request):
    logout(request)
    return redirect('/login/')


# ===== API =====
@api_view(['GET'])
@permission_classes([IsAuthenticated])
def secure_api(request):
    return Response({"message": "JWT working successfully"})